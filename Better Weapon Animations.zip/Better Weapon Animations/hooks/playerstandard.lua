
Hooks:PostHook(PlayerStandard, "_update_melee_timers", "immersive_fpcamera_melee_interupt", function(self, t, input)
	local melee_entry = managers.blackmarket:equipped_melee_weapon()
	if self._state_data.melee_expire_t and self._state_data.melee_expire_t <= t + tweak_data.blackmarket.melee_weapons[melee_entry].repeat_expire_t then
		self._state_data.melee_expire_t = nil
	end
end)
